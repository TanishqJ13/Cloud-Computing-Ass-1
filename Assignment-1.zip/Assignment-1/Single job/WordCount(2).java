import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.File;
import opennlp.tools.cmdline.postag.POSModelLoader;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.SimpleTokenizer;
public class WordCount {
	public static POSModel model = new POSModelLoader().load(new File("/home/gaurav/Desktop/sem8/cc/ass_1/opennlp-en-ud-ewt-pos-1.0-1.9.3.bin")); 
	public static POSTaggerME tagger = new POSTaggerME(model);
	public static SimpleTokenizer tokenizer = SimpleTokenizer.INSTANCE;
	public static class Arraydoublewritable extends ArrayWritable{
		public DoubleWritable[] values;
		public Arraydoublewritable()
		{
			super(DoubleWritable.class);
		}
	    public Arraydoublewritable(DoubleWritable[] val){
	        super(DoubleWritable.class,val);
	        values = new DoubleWritable[2];
	        values[0] = val[0];
	        values[1] = val[1];
	        set(val);
	    }
	    @Override
	    public String toString() {
	    	StringBuilder sb = new StringBuilder();
	    	for(String s: super.toStrings())
	    	{
	    		sb.append(s).append(" ");
	    	}
	    	return sb.toString();
	    }
	}
	public static class TokenizerMapper extends Mapper<Object, Text, Text, Arraydoublewritable> {
		@Override
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString();
			if(line != null) {
		    	String tokenizedLine[] = tokenizer.tokenize(line);
		    	String[] tags = tagger.tag(tokenizedLine); 
		    	double ncnt = 0.0;
		    	double tcnt = 0.0;
				for(String token : tags)
				{
					if(token.equals("NOUN"))
						ncnt+=1;
					tcnt+=1;
			  	}
				DoubleWritable[] temp = new DoubleWritable[2];
				temp[0] = new DoubleWritable(ncnt/tcnt);
				temp[1] = new DoubleWritable(tcnt);
				context.write(new Text("Key"), new Arraydoublewritable(temp));
			}
		}
	}
	public static class IntSumReducer extends Reducer<Text, Arraydoublewritable, Text, Arraydoublewritable> {
		@Override
		public void reduce(Text key, Iterable<Arraydoublewritable> values, Context context)throws IOException, InterruptedException {
			double tot = 0;
			double nouns_tot = 0;
			for (Arraydoublewritable val : values) {
				tot += ((DoubleWritable)val.get()[1]).get();
				nouns_tot += ((DoubleWritable)val.get()[0]).get() * ((DoubleWritable)val.get()[1]).get();
			}
			DoubleWritable[] temp = new DoubleWritable[2];
			temp[0] = new DoubleWritable(nouns_tot/tot);
			temp[1] = new DoubleWritable(tot);
			context.write(new Text("Key"), new Arraydoublewritable(temp));
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "wordcount");
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Arraydoublewritable.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Arraydoublewritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}