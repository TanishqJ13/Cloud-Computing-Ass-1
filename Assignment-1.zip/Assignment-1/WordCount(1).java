import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


import java.io.File;
import opennlp.tools.cmdline.postag.POSModelLoader;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.SimpleTokenizer;

public class WordCount {
	public static POSModel model = new POSModelLoader().load(new File("/home/gaurav/Desktop/sem8/cc/ass_1/opennlp-en-ud-ewt-pos-1.0-1.9.3.bin")); //outside mapper , universal declare to save runtime 
	public static POSTaggerME tagger = new POSTaggerME(model);
	public static SimpleTokenizer tokenizer = SimpleTokenizer.INSTANCE;
	public static class Arraydoublewritable extends ArrayWritable{
		public DoubleWritable[] values;
		public Arraydoublewritable()
		{
			super(DoubleWritable.class);
		}
	    public Arraydoublewritable(DoubleWritable[] val){
	        super(DoubleWritable.class,val);
	        values = new DoubleWritable[2];
	        values[0] = val[0];
	        values[1] = val[1];
	        set(val);
	    }
	    @Override
	    public String toString() {
	    	StringBuilder sb = new StringBuilder();
	    	for(String s: super.toStrings())sb.append(s).append(" ");
	    	return sb.toString();
	    }
	}
	public static class TokenizerMapper1 extends Mapper<Object, Text, Text, IntWritable> {
		@Override
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString();
			if(line != null){
		    	String tokenizedLine[] = tokenizer.tokenize(line); //word_tag
		    	String[] tags = tagger.tag(tokenizedLine); 
		    	for(int i=0;i<tags.length;i++){
		    		if(tags[i].equals("NOUN"))context.write(new Text(tokenizedLine[i]), new IntWritable(1));
		    		else context.write(new Text(tokenizedLine[i]), new IntWritable(0));
				}
			}//word_1 = noun , word_0 != noun // key = word, number of keys = number of reducers i.e. more parallel working hence easy computing. 
		}
	}
	public static class IntReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		@Override
		public void reduce(Text key, Iterable<IntWritable> values, Context context)throws IOException, InterruptedException { //combine for which noun occurs number of times. word ke liye N, _ & R, _
			int rest_tot = 0;
			int nouns_tot = 0;
			for (IntWritable val : values) {
				if(val.get()==0)rest_tot++;
				else nouns_tot++;
			}
			context.write(new Text("N"), new IntWritable(nouns_tot));
			context.write(new Text("R"), new IntWritable(rest_tot));
		}
	}
	public static class Mapper2 extends Mapper<LongWritable, Text, Text, Arraydoublewritable> {
		@Override //double writable for merge fractions, distinct word's N & R will be key i.e. long writable so that doesnot overflow. i.e. line number is key
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String temp = value.toString();
			String[] arrOfStr = temp.split("\t"); //line number || N/R || count
			DoubleWritable[] x = new DoubleWritable[2];
			x[1] = new DoubleWritable(Integer.parseInt(arrOfStr[1]) * 1.0);
			if(arrOfStr[0].equals("N"))x[0] = new DoubleWritable(1);
			else x[0] = new DoubleWritable(0);
			context.write(new Text("Key"), new Arraydoublewritable(x));
		}
	} // line by line ka fraction Tanishq, N=3, R=2 -> noun ke liye fraction =1 i.e. N = 1,3 R = 0, 2. Merge N & R for every line -> universal key for single output in reducer. 
	public static class IntSumReducer extends Reducer<Text, Arraydoublewritable, Text, Arraydoublewritable> {
		@Override
		public void reduce(Text key, Iterable<Arraydoublewritable> values, Context context)throws IOException, InterruptedException {
			double words_tot = 0;
			double nouns_tot = 0;
			for (Arraydoublewritable val : values) {
				words_tot += ((DoubleWritable)val.get()[1]).get();
				nouns_tot += ((DoubleWritable)val.get()[0]).get() * ((DoubleWritable)val.get()[1]).get();
			} // N -> 1*2 T -> 2, N -> + 0*1, T -> +1 . 
			DoubleWritable[] temp = new DoubleWritable[2];
			temp[0] = new DoubleWritable(nouns_tot/words_tot);
			temp[1] = new DoubleWritable(words_tot);
			context.write(new Text("Key"), new Arraydoublewritable(temp));
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf1 = new Configuration();
		Job job1 = Job.getInstance(conf1, "wordcount1");
		job1.setMapOutputKeyClass(Text.class);
		job1.setMapOutputValueClass(IntWritable.class);
		job1.setMapperClass(TokenizerMapper1.class);
		job1.setReducerClass(IntReducer.class);
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(IntWritable.class);
		
		FileInputFormat.addInputPath(job1, new Path(args[0]));
		FileOutputFormat.setOutputPath(job1, new Path(args[1]));
		job1.waitForCompletion(true);
		
		Configuration conf2 = new Configuration();
		Job job2 = Job.getInstance(conf2, "wordcount2");
		job2.setMapOutputKeyClass(Text.class);
		job2.setMapOutputValueClass(Arraydoublewritable.class);
		job2.setMapperClass(Mapper2.class);
		job2.setReducerClass(IntSumReducer.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(Arraydoublewritable.class);
		
		FileInputFormat.addInputPath(job2, new Path(args[1]));
		FileOutputFormat.setOutputPath(job2, new Path(args[2]));
		System.exit(job2.waitForCompletion(true) ? 0 : 1);
	}
}
